from View import cli

import sys 

sys.stdout.reconfigure(encoding="utf-8")

if __name__ == "__main__":
    cli.main()


#este programa ira armazenar e consultar nomes de países